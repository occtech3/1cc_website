<?php
/**
 * Front page (Home)
 *
 * Generated from src/pages/index.html by build.py; edit the source and rebuild.
 *
 * @package One_Christian_Church
 */

get_header();
?>
<main id="main">
<section class="hero hero-home">
  <div class="media"><div class="aurora" aria-hidden="true"><span></span><span></span><span></span><span></span></div><?php occ_video( 'hero', true ); ?></div>
  <div class="tint tint-color"></div><div class="tint tint-dark"></div>
  <div class="wrap hero-copy">
    <span class="live-pill"><span class="live-dot"></span>Sundays &middot; 9:00 coffee &middot; 10:00 worship</span>
    <h1><span class="line"><span>Love God.</span></span><span class="line"><span class="grad-text">Love People.</span></span></h1>
    <p class="rotator" data-rotator aria-label="Walk with Jesus. Make Disciples."><span class="script is-on" aria-hidden="true">Walk with Jesus.</span><span class="script" aria-hidden="true">Make Disciples.</span></p>
    <p class="lead">Life isn't found in programs, traditions or entertainment, but in Jesus alone. Come walk with us as we follow Him.</p>
    <div class="btn-row">
      <a class="btn btn-sun" href="<?php echo esc_url( occ_url( 'new-here', '' ) ); ?>">Plan a visit <svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
      <a class="btn btn-glass" href="https://www.facebook.com/OneChristianministry" target="_blank" rel="noopener"><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M10 8.5v7l6-3.5z"/></svg> Watch live</a>
    </div>
  </div>
  <button class="video-toggle" type="button" data-video-toggle aria-pressed="false">Pause video</button>
  <a class="scroll-cue" href="#welcome" aria-label="Scroll down"></a>
  <svg class="wave" viewBox="0 0 1440 90" preserveAspectRatio="none" aria-hidden="true"><path d="M0 46c120-26 240-38 360-24s240 52 360 52 240-40 360-50 240 6 360 26v40H0z"/></svg>
</section>

<div class="marquee" aria-hidden="true"><div class="marquee-track">
  <span>Love God</span><i>✦</i><span class="outline">Love People</span><i>✦</i><span>Walk with Jesus</span><i>✦</i><span class="outline">Make Disciples</span><i>✦</i><span>Love God</span><i>✦</i><span class="outline">Love People</span><i>✦</i><span>Walk with Jesus</span><i>✦</i><span class="outline">Make Disciples</span><i>✦</i>
</div></div>

<section class="section dark" id="welcome">
  <div class="wrap statement-wrap">
    <div class="reveal">
      <p class="kicker">Welcome home</p>
      <div class="badge-spin" aria-hidden="true">
        <svg viewBox="0 0 150 150"><defs><path id="circ" d="M75 75m-58 0a58 58 0 1 1 116 0a58 58 0 1 1-116 0"/></defs><text><textPath href="#circ">Love God &#8226; Love People &#8226; Walk with Jesus &#8226;</textPath></text></svg>
        <svg class="mark" xmlns="http://www.w3.org/2000/svg" viewBox="34 11.5 174 174" fill="currentColor" aria-hidden="true"><path d="M59.8 103.8L58.6 102.0L57.9 100.1L57.3 98.2L56.8 96.2L56.4 94.2L56.1 92.2L55.8 90.1L55.6 88.0L55.5 85.9L55.4 83.8L55.5 81.7L55.5 79.6L55.7 77.4L56.0 75.3L56.3 73.1L56.7 71.0L57.1 68.8L57.7 66.6L58.3 64.5L59.0 62.4L59.7 60.2L60.6 58.1L61.5 56.0L62.5 54.0L63.5 51.9L64.7 49.9L65.9 47.9L67.2 45.9L68.5 44.0L70.0 42.1L71.5 40.3L73.0 38.5L74.7 36.8L76.4 35.1L78.2 33.4L80.0 31.9L81.9 30.3L83.9 28.9L85.9 27.5L88.0 26.1L90.1 24.9L92.2 23.7L94.5 22.6L96.7 21.6L99.0 20.6L101.4 19.7L103.8 18.9L106.2 18.2L108.6 17.6L111.1 17.1L113.6 16.7L116.1 16.3L118.6 16.1L121.2 15.9L123.7 15.8L126.2 15.9L128.8 16.0L131.3 16.2L133.8 16.6L136.4 17.0L138.9 17.5L141.3 18.1L143.8 18.9L146.2 19.7L148.6 20.6L150.9 21.6L153.1 22.8L155.3 24.1L157.4 25.6L158.3 26.6L155.7 26.3L153.3 25.6L150.9 25.0L148.5 24.4L146.1 23.8L143.7 23.4L141.3 22.9L139.0 22.6L136.6 22.4L134.2 22.2L131.8 22.1L129.4 22.0L127.0 22.1L124.7 22.2L122.3 22.4L120.0 22.7L117.7 23.0L115.4 23.4L113.1 23.9L110.8 24.5L108.6 25.1L106.4 25.9L104.3 26.6L102.2 27.5L100.1 28.4L98.0 29.4L96.0 30.4L94.1 31.6L92.2 32.7L90.3 34.0L88.5 35.2L86.7 36.5L85.0 37.9L83.4 39.4L81.8 40.8L80.2 42.4L78.7 43.9L77.3 45.5L75.9 47.1L74.6 48.8L73.3 50.5L72.2 52.2L71.0 54.0L69.9 55.8L68.9 57.6L68.0 59.4L67.1 61.3L66.2 63.1L65.5 65.0L64.7 66.9L64.1 68.8L63.5 70.7L62.9 72.6L62.4 74.5L62.0 76.4L61.6 78.3L61.3 80.2L61.0 82.1L60.7 84.0L60.5 85.9L60.4 87.8L60.3 89.7L60.2 91.6L60.2 93.5L60.2 95.4L60.2 97.3L60.2 99.1L60.2 101.0L60.2 102.9Z"/><path d="M106.0 38.2L107.7 36.9L109.5 35.9L111.4 35.1L113.4 34.4L115.3 33.7L117.3 33.1L119.4 32.6L121.5 32.2L123.6 31.8L125.7 31.5L127.8 31.3L130.0 31.1L132.2 31.0L134.4 31.0L136.6 31.1L138.8 31.2L141.0 31.4L143.2 31.7L145.4 32.1L147.7 32.5L149.9 33.0L152.1 33.6L154.3 34.3L156.5 35.0L158.7 35.8L160.8 36.7L163.0 37.7L165.1 38.8L167.2 39.9L169.2 41.1L171.2 42.4L173.2 43.7L175.2 45.1L177.1 46.6L178.9 48.2L180.7 49.8L182.5 51.5L184.2 53.3L185.8 55.1L187.4 57.0L188.9 59.0L190.4 61.0L191.8 63.1L193.1 65.2L194.3 67.4L195.5 69.7L196.6 71.9L197.6 74.2L198.5 76.6L199.3 79.0L200.1 81.4L200.7 83.9L201.3 86.4L201.8 88.9L202.1 91.4L202.4 94.0L202.6 96.5L202.7 99.1L202.7 101.7L202.5 104.2L202.3 106.8L202.0 109.3L201.6 111.9L201.0 114.4L200.4 116.9L199.6 119.3L198.7 121.7L197.7 124.1L196.4 126.3L195.5 127.3L195.6 124.7L196.0 122.2L196.4 119.8L196.8 117.3L197.0 114.8L197.2 112.4L197.4 110.0L197.4 107.5L197.4 105.1L197.3 102.7L197.1 100.3L196.8 97.9L196.5 95.5L196.1 93.2L195.5 90.8L195.0 88.5L194.3 86.3L193.6 84.0L192.8 81.8L191.9 79.7L191.0 77.5L190.0 75.5L188.9 73.4L187.8 71.4L186.6 69.5L185.4 67.5L184.1 65.7L182.7 63.9L181.3 62.1L179.9 60.4L178.4 58.8L176.8 57.2L175.3 55.7L173.6 54.2L172.0 52.8L170.3 51.4L168.6 50.1L166.8 48.9L165.0 47.7L163.2 46.6L161.4 45.5L159.5 44.5L157.6 43.6L155.7 42.7L153.8 41.9L151.9 41.1L150.0 40.4L148.0 39.8L146.1 39.2L144.1 38.7L142.1 38.2L140.1 37.8L138.2 37.5L136.2 37.2L134.2 36.9L132.2 36.7L130.3 36.6L128.3 36.5L126.3 36.5L124.4 36.5L122.4 36.6L120.5 36.7L118.5 36.8L116.6 37.0L114.7 37.3L112.8 37.5L110.8 37.8L108.9 38.1L107.0 38.4Z"/><path d="M153.2 154.3L151.4 156.1L149.4 157.3L147.2 158.3L145.0 159.3L142.7 160.2L140.4 160.9L138.1 161.6L135.8 162.2L133.4 162.8L131.0 163.2L128.6 163.6L126.2 163.8L123.8 164.1L121.4 164.2L119.0 164.3L116.5 164.2L114.1 164.2L111.6 164.0L109.2 163.7L106.8 163.4L104.3 163.0L101.9 162.5L99.5 162.0L97.1 161.3L94.7 160.6L92.3 159.8L89.9 158.9L87.6 158.0L85.2 157.0L82.9 155.8L80.7 154.7L78.4 153.4L76.2 152.0L74.0 150.6L71.9 149.1L69.8 147.5L67.7 145.8L65.7 144.1L63.7 142.3L61.8 140.3L59.9 138.4L58.1 136.3L56.4 134.2L54.7 132.0L53.0 129.7L51.5 127.3L50.0 124.9L48.7 122.4L47.4 119.9L46.1 117.2L45.0 114.6L44.0 111.8L43.0 109.0L42.2 106.2L41.5 103.3L40.9 100.4L40.3 97.4L39.9 94.4L39.7 91.4L39.5 88.3L39.5 85.2L39.6 82.1L39.8 79.0L40.1 75.9L40.7 72.8L41.3 69.7L42.1 66.7L43.1 63.7L44.4 60.8L45.5 59.6L45.6 63.1L45.4 66.4L45.2 69.5L45.0 72.7L45.0 75.7L45.0 78.8L45.2 81.8L45.4 84.8L45.7 87.7L46.1 90.5L46.7 93.4L47.3 96.1L47.9 98.9L48.7 101.5L49.6 104.2L50.5 106.7L51.5 109.2L52.6 111.7L53.7 114.0L54.9 116.3L56.2 118.6L57.5 120.8L58.9 122.9L60.4 125.0L61.9 127.0L63.4 128.9L65.0 130.8L66.7 132.6L68.3 134.3L70.0 135.9L71.8 137.5L73.6 139.0L75.4 140.5L77.3 141.9L79.2 143.2L81.0 144.5L83.0 145.7L84.9 146.8L86.9 147.9L88.9 148.9L90.9 149.8L92.9 150.7L95.0 151.6L97.0 152.3L99.1 153.0L101.1 153.7L103.2 154.3L105.3 154.8L107.4 155.3L109.5 155.7L111.7 156.1L113.8 156.4L116.0 156.7L118.1 156.9L120.3 157.1L122.4 157.2L124.6 157.2L126.8 157.2L129.0 157.2L131.2 157.1L133.4 156.9L135.6 156.7L137.9 156.5L140.1 156.2L142.4 155.8L144.7 155.4L147.0 155.0L149.4 154.6L151.8 154.2Z"/><path d="M185.2 97.4L186.4 99.4L187.0 101.4L187.4 103.5L187.8 105.6L188.1 107.7L188.2 109.8L188.3 112.0L188.3 114.1L188.2 116.3L188.1 118.5L187.8 120.7L187.5 122.9L187.1 125.0L186.7 127.2L186.1 129.4L185.5 131.6L184.8 133.7L184.0 135.9L183.1 138.0L182.2 140.1L181.2 142.1L180.1 144.2L178.9 146.2L177.7 148.2L176.4 150.1L175.0 152.0L173.6 153.9L172.0 155.7L170.5 157.5L168.8 159.2L167.1 160.9L165.3 162.5L163.5 164.1L161.6 165.6L159.7 167.0L157.6 168.4L155.6 169.7L153.5 171.0L151.3 172.1L149.1 173.2L146.9 174.3L144.6 175.2L142.3 176.1L139.9 176.9L137.6 177.6L135.2 178.2L132.7 178.8L130.3 179.2L127.8 179.6L125.3 179.8L122.8 180.0L120.3 180.1L117.8 180.1L115.3 180.0L112.8 179.8L110.3 179.6L107.8 179.2L105.3 178.7L102.9 178.2L100.5 177.5L98.1 176.8L95.7 175.9L93.4 175.0L91.1 174.0L88.9 172.8L86.7 171.6L84.6 170.3L82.6 168.8L80.7 167.2L80.0 166.1L82.4 166.7L84.7 167.5L86.9 168.4L89.2 169.2L91.4 170.0L93.7 170.7L96.0 171.3L98.3 171.9L100.6 172.3L102.9 172.8L105.2 173.1L107.6 173.4L109.9 173.6L112.2 173.7L114.6 173.7L116.9 173.7L119.2 173.5L121.5 173.3L123.8 173.1L126.1 172.7L128.3 172.3L130.6 171.8L132.8 171.3L134.9 170.6L137.1 169.9L139.2 169.2L141.3 168.3L143.4 167.4L145.4 166.5L147.4 165.5L149.3 164.4L151.2 163.2L153.1 162.1L154.9 160.8L156.6 159.5L158.4 158.2L160.0 156.8L161.6 155.3L163.2 153.8L164.7 152.3L166.2 150.7L167.6 149.1L168.9 147.5L170.2 145.8L171.4 144.1L172.6 142.3L173.7 140.6L174.8 138.8L175.8 136.9L176.7 135.1L177.6 133.3L178.4 131.4L179.2 129.5L179.9 127.6L180.6 125.7L181.2 123.7L181.7 121.8L182.2 119.9L182.7 117.9L183.0 116.0L183.4 114.0L183.7 112.0L183.9 110.1L184.1 108.1L184.3 106.2L184.4 104.2L184.5 102.3L184.6 100.3L184.8 98.4Z"/><path d="M118 63L126 63Q123.3 108.5 126 154L118 154Q120.7 108.5 118 63Z"/><path d="M95 88L95 96Q122 93.8 149 96L149 88Q122 90.2 95 88Z"/></svg>
      </div>
    </div>
    <div>
      <p class="statement" data-fill>We believe life isn't found in programs, traditions or entertainment, but in <mark>Jesus alone.</mark> We aim to be ordinary people who live with <mark>extraordinary devotion,</mark> set apart for His glory and united in His mission.</p>
      <a class="text-link reveal" href="<?php echo esc_url( occ_url( 'about', '' ) ); ?>">Our story &amp; beliefs <svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
    </div>
  </div>
</section>

<section class="story" data-story style="--panels:4">
  <div class="story-sticky">
    <div class="media story-media">
      <div class="aurora" aria-hidden="true"><span></span><span></span><span></span><span></span></div>
      <?php occ_video( 'love-god', false ); ?>
      <?php occ_video( 'love-people', false ); ?>
      <?php occ_video( 'walk', false ); ?>
      <?php occ_video( 'disciples', false ); ?>
    </div>
    <div class="tint tint-color"></div><div class="tint tint-dark"></div>
    <div class="story-copy">
      <div class="wrap story-panels">
        <div class="story-panel is-active"><span class="num">01 / 04</span><h2>Love<br><span class="grad-text">God.</span></h2><p>Worship that centers on Jesus, not on a show. Every gathering points us back to Him.</p></div>
        <div class="story-panel"><span class="num">02 / 04</span><h2>Love<br><span class="grad-text">People.</span></h2><p>A church family where newcomers are welcomed by name and nobody walks alone.</p></div>
        <div class="story-panel"><span class="num">03 / 04</span><h2>Walk with<br><span class="grad-text">Jesus.</span></h2><p>Learning to live biblically and pursue holiness in a world that pulls us toward compromise.</p></div>
        <div class="story-panel"><span class="num">04 / 04</span><h2>Make<br><span class="grad-text">Disciples.</span></h2><p>Being the church as God intended: set apart for His glory and united in His mission.</p></div>
      </div>
    </div>
    <div class="story-progress" aria-hidden="true"><span><i></i></span><span><i></i></span><span><i></i></span><span><i></i></span></div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="section-head">
      <div class="reveal"><p class="kicker">Get connected</p><h2>There's a place<br>for <span class="grad-electric-text">you</span> here.</h2></div>
      <a class="btn btn-line reveal" href="<?php echo esc_url( occ_url( 'ministries', '' ) ); ?>">All ministries <svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
    </div>
    <div class="vcards">
      <a class="vcard reveal" href="<?php echo esc_url( occ_url( 'ministries', 'kids' ) ); ?>" style="--c1:#FFC93C;--c2:#FF7A1A">
        <div class="media"><?php occ_video( 'kids', false ); ?></div><div class="vcard-tint"></div>
        <div class="vcard-body"><span class="chip">Infants &ndash; 5th grade</span><h3>OCC Kids</h3><p>Teaching our kids the gospel and how to love and walk with Jesus. Sundays at 10am.</p><span class="vcard-go">Explore <svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></span></div>
      </a>
      <a class="vcard reveal" href="<?php echo esc_url( occ_url( 'ministries', 'youth' ) ); ?>" style="--c1:#7B3FF2;--c2:#FF2D87;--chip:#18D1C0">
        <div class="media"><?php occ_video( 'youth', false ); ?></div><div class="vcard-tint"></div>
        <div class="vcard-body"><span class="chip" style="--chip:#18D1C0">6th &ndash; 12th grade</span><h3>OCC Youth</h3><p>Worship, life groups and games. Wednesdays 6:30&ndash;8pm. Snacks provided!</p><span class="vcard-go">Explore <svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></span></div>
      </a>
      <a class="vcard reveal" href="<?php echo esc_url( occ_url( 'ministries', 'adults' ) ); ?>" style="--c1:#2E9BFF;--c2:#18D1C0">
        <div class="media"><?php occ_video( 'students', false ); ?></div><div class="vcard-tint"></div>
        <div class="vcard-body"><span class="chip" style="--chip:#FF2D87">Men, women &amp; seniors</span><h3>Adults</h3><p>Bible studies, Men's Fire, Women's Fire, Crafters, breakfasts and more.</p><span class="vcard-go">Explore <svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></span></div>
      </a>
    </div>
  </div>
</section>

<section class="section paper">
  <div class="wrap split">
    <div class="visit-media reveal from-left">
      <span class="blob b1"></span><span class="blob b2"></span>
      <div class="frame"><div class="media"><?php occ_video( 'adults', false ); ?></div></div>
      <span class="sticker s1"><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 9h13v5a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5z"/><path d="M17 11h1.5a2.5 2.5 0 0 1 0 5H17"/><path d="M8 3v3M12 3v3"/></svg> Coffee at 9:00</span>
      <span class="sticker s2"><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="9" width="18" height="12" rx="1.5"/><path d="M3 13h18M12 9v12"/><path d="M12 9c-2-4-6-4-6-1.5S9 9 12 9c3 0 6-.5 6-1.5S14 5 12 9"/></svg> A gift for first-timers</span>
    </div>
    <div>
      <div class="reveal"><p class="kicker">Your first Sunday</p><h2>Here's what<br>to expect.</h2>
      <p>No pressure, no performance. Just a warm welcome and a church family glad you came.</p></div>
      <ol class="steps">
        <li class="reveal"><div><h3>Come early for coffee</h3><p>Sunday Morning Fellowship starts at 9:00 with coffee and conversation.</p></div></li>
        <li class="reveal"><div><h3>Stop by the Welcome Center</h3><p>Across from the main entrance, staffed before and after service, with a gift bag for first-time guests.</p></div></li>
        <li class="reveal"><div><h3>Kids are cared for</h3><p>Infants through 5th grade have their own classes during the 10:00 service.</p></div></li>
        <li class="reveal"><div><h3>Worship &amp; the Word</h3><p>Heartfelt worship and Bible-centered teaching from Pastor Jerry.</p></div></li>
      </ol>
      <div class="btn-row reveal"><a class="btn btn-night" href="<?php echo esc_url( occ_url( 'new-here', '' ) ); ?>">Plan your visit <svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a></div>
    </div>
  </div>
</section>

<section class="section dark">
  <div class="wrap">
    <div class="section-head">
      <div class="reveal"><p class="kicker">This week</p><h2>Gather <span class="grad-text">with us.</span></h2></div>
      <a class="text-link reveal" href="<?php echo esc_url( occ_url( 'events', '' ) ); ?>">All events <svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
    </div>
    <div class="week-grid">
      <div class="tile t-pink reveal"><span class="day">Sun</span><h3>Fellowship &amp; Worship</h3><p>9:00am coffee &middot; 10:00am service</p></div>
      <div class="tile t-orange reveal"><span class="day">Mon</span><h3>Women's Fire</h3><p>6:30pm &middot; Prayer Room</p></div>
      <div class="tile t-yellow reveal"><span class="day">Tue</span><h3>Crafters</h3><p>6:30pm &middot; crafts, snack &amp; devotional</p></div>
      <div class="tile t-aqua reveal"><span class="day">Wed</span><h3>OCC Youth</h3><p>6:30&ndash;8:00pm &middot; grades 6&ndash;12</p></div>
      <div class="tile t-violet reveal"><span class="day">Thu</span><h3>Men's Fire</h3><p>6:30pm &middot; 3rd Thursday monthly</p></div>
    </div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="carousel" data-carousel>
      <div class="section-head">
        <div class="reveal"><p class="kicker">Mark your calendar</p><h2>What's coming up</h2></div>
        <div class="carousel-nav reveal"><button class="round-btn prev" type="button" data-dir="-1" aria-label="Previous"><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button><button class="round-btn" type="button" data-dir="1" aria-label="Next"><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button></div>
      </div>
      <div class="carousel-track">
        <a class="promo p1 reveal" href="<?php echo esc_url( occ_url( 'events', '' ) ); ?>"><svg class="ico ico-lg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22c4 0 7-3 7-7 0-5-4-7-5-11-2 2-3 4-3 6-1-1-2-2-2-4-2 2-4 5-4 9 0 4 3 7 7 7z"/></svg><div><span class="when">3rd Thursday &middot; 6:30pm</span><h3>Men's Fire</h3><p>Mark Spencer speaks in the Prayer Room.</p></div></a>
        <a class="promo p2 reveal" href="<?php echo esc_url( occ_url( 'events', '' ) ); ?>"><svg class="ico ico-lg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/></svg><div><span class="when">Mondays &middot; 6:30pm</span><h3>Women's Fire</h3><p>Bible study in the Prayer Room with Becky Smart.</p></div></a>
        <a class="promo p3 reveal" href="<?php echo esc_url( occ_url( 'ministries', 'griefshare' ) ); ?>"><svg class="ico ico-lg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 21c-3-2-8-5-8-10V5l4 2 4-4 4 4 4-2v6c0 5-5 8-8 10z"/></svg><div><span class="when">Saturdays &middot; 10am</span><h3>GriefShare</h3><p>A 13-week support group. You don't have to grieve alone.</p></div></a>
        <a class="promo p4 reveal" href="<?php echo esc_url( occ_url( 'ministries', 'adults' ) ); ?>"><svg class="ico ico-lg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 11h18M5 11V8a7 7 0 0 1 14 0v3M4 11l2 9h12l2-9"/></svg><div><span class="when">Every other month</span><h3>The Incredibles</h3><p>Seniors' luncheon for ages 55 and older.</p></div></a>
        <a class="promo p5 reveal" href="<?php echo esc_url( occ_url( 'ministries', 'adults' ) ); ?>"><svg class="ico ico-lg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 9h13v5a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5z"/><path d="M17 11h1.5a2.5 2.5 0 0 1 0 5H17"/><path d="M8 3v3M12 3v3"/></svg><div><span class="when">At the church</span><h3>Men's Breakfast</h3><p>Jesus, <em>and</em> breakfast? Yes.</p></div></a>
        <a class="promo p6 reveal" href="<?php echo esc_url( occ_url( 'listen', '' ) ); ?>"><svg class="ico ico-lg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="8" width="18" height="12" rx="2"/><path d="M7 8 17 3"/><circle cx="15" cy="14" r="3"/><path d="M6 12h3M6 16h3"/></svg><div><span class="when">Sundays &middot; 12:00</span><h3>Freedom 95</h3><p>Pastor Jerry on the radio every Sunday.</p></div></a>
      </div>
    </div>
  </div>
</section>

<section class="section dark">
  <div class="wrap">
    <div class="section-head">
      <div class="reveal"><p class="kicker">Meet our leaders</p><h2>Glad you're <span class="grad-text">here.</span></h2></div>
      <a class="text-link reveal" href="<?php echo esc_url( occ_url( 'about', 'leaders' ) ); ?>">About our team <svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
    </div>
    <div class="leaders">
      <div class="leader reveal"><div class="avatar" aria-hidden="true">JS</div><h3>Jerry Shomali</h3><p>Senior Pastor</p><span class="photo-soon">Photo coming soon</span></div>
      <div class="leader reveal"><div class="avatar" aria-hidden="true">DS</div><h3>Dena Shomali</h3><p>Director of Worship &amp; Media</p><span class="photo-soon">Photo coming soon</span></div>
      <div class="leader reveal"><div class="avatar" aria-hidden="true">D&amp;J</div><h3>Devon &amp; Jordyn Matthews</h3><p>Youth Directors</p><span class="photo-soon">Photo coming soon</span></div>
    </div>
  </div>
</section>

<section class="band">
  <div class="media"><div data-parallax="0.12" style="position:absolute;inset:0"><div class="aurora" aria-hidden="true"><span></span><span></span><span></span><span></span></div><?php occ_video( 'mic', false ); ?></div></div>
  <div class="tint tint-color"></div><div class="tint tint-dark"></div>
  <div class="wrap">
    <p class="kicker reveal" style="color:var(--yellow)">Watch &amp; listen</p>
    <h2 class="reveal">Can't make it <span class="script" style="font-size:1.05em">Sunday?</span></h2>
    <p class="reveal">Services stream live on Facebook, and you can hear Pastor Jerry on Freedom 95 Radio every Sunday at 12:00.</p>
    <div class="btn-row reveal">
      <a class="btn btn-sun" href="https://www.facebook.com/OneChristianministry" target="_blank" rel="noopener"><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M10 8.5v7l6-3.5z"/></svg> Watch live</a>
      <a class="btn btn-glass" href="https://www.freedom95.us/" target="_blank" rel="noopener"><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="8" width="18" height="12" rx="2"/><path d="M7 8 17 3"/><circle cx="15" cy="14" r="3"/><path d="M6 12h3M6 16h3"/></svg> Freedom 95</a>
      <a class="btn btn-glass" href="https://www.youtube.com/channel/UCYVLSh8gjUrTDR09XfRN5Dg" target="_blank" rel="noopener"><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2.5" y="5.5" width="19" height="13" rx="4"/><path d="m10 9 5 3-5 3z"/></svg> YouTube</a>
    </div>
  </div>
</section>

</main>
<?php
get_footer();
