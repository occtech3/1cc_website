# Credits and licences

## Background videos (placeholders)

Stock clips from [Mixkit](https://mixkit.co/), each listed on its page under the **Mixkit Stock Video Free License**
(checked clip by clip in October 2026). They stand in until the church has its own footage.

| File | Shows | Source |
|---|---|---|
| `hero.mp4` | Guitarist on stage (home hero) | [mixkit.co/free-stock-video/guitarist-playing-on-stage-486](https://mixkit.co/free-stock-video/guitarist-playing-on-stage-486/) |
| `love-god.mp4` | Singer on stage (story: Love God) | [mixkit.co/free-stock-video/a-long-haired-woman-singing-on-stage-478](https://mixkit.co/free-stock-video/a-long-haired-woman-singing-on-stage-478/) |
| `love-people.mp4` | Friends laughing (story: Love People) | [mixkit.co/free-stock-video/a-couple-of-friends-sitting-laughing-with-their-cell-phones-4537](https://mixkit.co/free-stock-video/a-couple-of-friends-sitting-laughing-with-their-cell-phones-4537/) |
| `walk.mp4` | People praying, holding hands (story: Walk with Jesus) | [mixkit.co/free-stock-video/praying-people-holding-hands-black-and-white-shot-1514](https://mixkit.co/free-stock-video/praying-people-holding-hands-black-and-white-shot-1514/) |
| `disciples.mp4` | Crowd at a concert (story: Make Disciples) | [mixkit.co/free-stock-video/audience-at-a-concert-4269](https://mixkit.co/free-stock-video/audience-at-a-concert-4269/) |
| `kids.mp4` | Kids running on a pier (Kids) | [mixkit.co/free-stock-video/three-kids-running-in-a-wooden-pier-48264](https://mixkit.co/free-stock-video/three-kids-running-in-a-wooden-pier-48264/) |
| `youth.mp4` | Young people group hug (Youth) | [mixkit.co/free-stock-video/cheerful-young-people-giving-each-other-a-group-hug-4709](https://mixkit.co/free-stock-video/cheerful-young-people-giving-each-other-a-group-hug-4709/) |
| `adults.mp4` | Friends at a coffee shop (Adults, coffee) | [mixkit.co/free-stock-video/date-between-two-girl-friends-in-a-coffee-shop-41813](https://mixkit.co/free-stock-video/date-between-two-girl-friends-in-a-coffee-shop-41813/) |
| `students.mp4` | Students talking over coffee (Events) | [mixkit.co/free-stock-video/students-in-a-cafeteria-discussing-an-assignment-4794](https://mixkit.co/free-stock-video/students-in-a-cafeteria-discussing-an-assignment-4794/) |
| `mic.mp4` | Microphone (Watch & Listen) | [mixkit.co/free-stock-video/microphone-in-a-party-hall-4632](https://mixkit.co/free-stock-video/microphone-in-a-party-hall-4632/) |
| `guitar.mp4` | Guitar close-up (Give) | [mixkit.co/free-stock-video/playing-guitar-close-up-483](https://mixkit.co/free-stock-video/playing-guitar-close-up-483/) |

How they are used, to stay inside Mixkit's terms (<https://mixkit.co/terms/>):

- The files are downloaded by hand and hosted with the site. The site never links to or streams from Mixkit's servers.
- They are part of the website only. They are not offered for download on their own, and they are not bundled in the WordPress theme zip.
- They are shown as general mood footage. Nothing on the site names the people in them or suggests they attend or endorse the church.

Before the site goes live, open each clip's page, click **View License** and confirm it still says "Free License",
and read Envato's Acceptable Use Policy (linked from Mixkit's terms). The full licence text is only shown on those pages.

## Fonts

Anton, Caveat and Plus Jakarta Sans from Google Fonts, under the SIL Open Font License 1.1.

## Logo

One Christian Church's circle-and-cross logo, redrawn as a vector (`assets/img/logo-mark.svg`). Owned by the church.
